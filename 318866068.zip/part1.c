#define INVALID_INPUT 0.5
#define LOG_BASE 2
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
//Calculates and prints the required statics depending on the input
void powerPrint(int* num_array,int length);
//Scans the input from the user
bool numArrayInput(int* num_array,int length);
//Calculate log2 of given number
double log_2(double num);
double log_2(double num){
    if(num<=0){
        return INVALID_INPUT;
    }
    if(num<=1){
        return num-1;
    }
    else{
        return (1+log_2(num/LOG_BASE));
    }
}
int inputSize(){
    int size;
    printf("Enter size of input:\n");
    scanf("%d",&size);
    return size;
}
bool numArrayInput(int* num_array,int length){
    int i;
    printf("Enter numbers:\n");
    for(i=0;i<length;i++){
        if(scanf("%d",&num_array[i])==0){
            printf("Invalid number\n");
            return false;
        }
        
    }
    return true;
}
void powerPrint(int* num_array,int length){
    int i,sum=0;
    double j=0;
    for(i=0;i<length;i++){
        j=log_2(num_array[i]);
        if((j-(int) j)==0){
            printf("The number %d is a power of 2: %d = 2^%d\n",num_array[i],num_array[i],(int)j);
            sum+=(int) j;
        }

    }
    printf("Total exponent sum is %d\n",sum);

}
int main(){
    int size=inputSize();
    if(size<1){
        printf("Invalid size\n");
        return 0;
    }
    int* num_array=malloc(sizeof(int)*size);
    if(num_array==NULL){
        printf("Memory error\n");
        return 0;
    }
    if(numArrayInput(num_array,size)){
        powerPrint(num_array,size);
    }
    free(num_array);
    return 0;
}